export const darkModeKey = "darkMode";

export const styleKey = "style";

export const containerMaxW = "xl:max-w-7xl xl:mx-auto";
